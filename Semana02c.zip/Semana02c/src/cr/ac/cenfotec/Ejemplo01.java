/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.cenfotec;

/**
 *
 * @author admin
 */
public class Ejemplo01 {

    public static void main(String[] args) {
        int votosValidos, cantidadDiputaciones, votosPartido, cantidadDiputados, cifraResidual;
        double cociente, subCociente;

        //input
        votosValidos = EntradaConsolaSimple.leerEntero("Digite la cantidad de votos validos: ");
        cantidadDiputaciones = EntradaConsolaSimple.leerEntero("Digite la cantidad de diputaciones: ");
        votosPartido = EntradaConsolaSimple.leerEntero("Digite los votos del partido: ");
        //process
        cociente = (double) votosValidos / cantidadDiputaciones;
        subCociente = cociente / 2;

        cantidadDiputados = (int) (votosPartido / cociente);
        cifraResidual = (int) (votosPartido % cociente);

        //output
        System.out.println("Cantidad de diputados: " + cantidadDiputados);
        System.out.println("Cifra residual: " + cifraResidual);
    }
}
