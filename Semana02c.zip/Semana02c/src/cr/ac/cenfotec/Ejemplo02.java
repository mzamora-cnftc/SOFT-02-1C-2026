/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.cenfotec;

/**
 *
 * @author admin
 */
public class Ejemplo02 {
    public static void main(String[] args) {
        int votosValidos, cantidadDiputaciones, votosPartido, cantidadDiputados, cifraResidual;
        double cociente, subCociente;

        //input
        //votosValidos = EntradaConsolaSimple.leerEntero("Digite la cantidad de votos validos: ");
        votosValidos = EntradaVisualSimple.leerNumeroEnteroHastaValido("Digite la cantidad de votos v�lidos", 
                "Ingreso");
        //cantidadDiputaciones = EntradaConsolaSimple.leerEntero("Digite la cantidad de diputaciones: ");
        cantidadDiputaciones = EntradaVisualSimple.leerNumeroEnteroHastaValido("Digite la cantidad de diputaciones:", 
                "Ingreso");
        //votosPartido = EntradaConsolaSimple.leerEntero("Digite los votos del partido: ");
        votosPartido = EntradaVisualSimple.leerNumeroEnteroHastaValido("Digite los votos del partido: ", 
                "Ingreso");
        
        
        //process
        cociente = (double) votosValidos / cantidadDiputaciones;
        subCociente = cociente / 2;

        cantidadDiputados = (int) (votosPartido / cociente);
        cifraResidual = (int) (votosPartido % cociente);

        //output
        System.out.println("Cantidad de diputados: " + cantidadDiputados);
        System.out.println("Cifra residual: " + cifraResidual);
    }
}
