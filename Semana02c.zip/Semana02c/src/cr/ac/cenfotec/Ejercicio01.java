/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.cenfotec;

/**
 *
 * @author admin
 */
public class Ejercicio01 {
    public static void main(String[] args) {
        //declaraci�n de variables
        double salarioBruto, salarioNeto, caja, pension, asociacion;
        String nombre;
        
        //input
        EntradaConsolaSimple.limpiarConsola();
        nombre = EntradaConsolaSimple.leerString("Digite el nombre: ");
        salarioBruto = EntradaConsolaSimple.leerDoble("Digite su salario sin deducciones: ");
        
        //process
        caja = salarioBruto * (9.75/100);
        pension = salarioBruto * 0.0925;
        asociacion = salarioBruto * (13.8 /100);
        
        salarioNeto = salarioBruto - (caja+asociacion+pension);
        
        //output
        EntradaConsolaSimple.limpiarConsola();
        System.out.printf("Estimado trabajado %s el salario de este mes se desglosa:\n",nombre);
        System.out.printf("%-20s: %12.2f\n", "Salario bruto",salarioBruto);
        System.out.printf("%-20s: %12.2f\n", "Caja",caja);
        System.out.printf("%-20s: %12.2f\n", "Pensi�n",pension);
        System.out.printf("%-20s: %12.2f\n", "Asociaci�n",asociacion);
        System.out.printf("%-20s: %12.2f\n", "Salario neto",salarioNeto);
        
    }
}
